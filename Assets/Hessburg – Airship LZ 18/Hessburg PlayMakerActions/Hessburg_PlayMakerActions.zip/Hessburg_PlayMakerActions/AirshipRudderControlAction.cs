﻿using UnityEngine;
using Hessburg;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("Hessburg")]
    [Tooltip("Helper tool to animate rotor, doors and gun of 'PBR Attack Helicopter of the Vietnam War'")]


    public class AirshipRudderControlAction : FsmStateAction
    {
        [RequiredField]

        [CheckForComponent(typeof(AirshipController))]       
        public FsmOwnerDefault gameObject;

        [HasFloatSlider(35.0f, -35.0f)]
        public FsmFloat RudderAngle;

        public FsmBool everyFrame;

        AirshipController theScript;
  
        public override void Reset()
        {
          	gameObject = null;
			RudderAngle=0.0f;
            everyFrame = true;
        }
       
        public override void OnEnter()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            theScript = go.GetComponent<AirshipController>();

            if (!everyFrame.Value)
            {
                AirshipControllerUpdate();
                Finish();
            }

        }

        public override void OnUpdate()
        {
            if (everyFrame.Value)
            {
                AirshipControllerUpdate();
            }
        }

        void AirshipControllerUpdate()
        { 
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null)
            {
                return;
            }

            theScript.RudderAngle = RudderAngle.Value;
        }

    }
}