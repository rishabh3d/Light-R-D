﻿using UnityEngine;
using Hessburg;

namespace HutongGames.PlayMaker.Actions
{
    [ActionCategory("Hessburg")]
    [Tooltip("Helper tool to animate rotor, doors and gun of 'PBR Attack Helicopter of the Vietnam War'")]


    public class AirshipRPMControlAction : FsmStateAction
    {
        [RequiredField]

        [CheckForComponent(typeof(AirshipController))]       
        public FsmOwnerDefault gameObject;

        [HasFloatSlider(-1200.0f, 1200.0f)]
        public FsmFloat RPM;

        public FsmBool everyFrame;

        AirshipController theScript;
  
        public override void Reset()
        {
          	gameObject = null;
        	RPM = 0.0f;
            everyFrame = true;
        }
       
        public override void OnEnter()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            theScript = go.GetComponent<AirshipController>();

            if (!everyFrame.Value)
            {
                AirshipControllerUpdate();
                Finish();
            }

        }

        public override void OnUpdate()
        {
            if (everyFrame.Value)
            {
                AirshipControllerUpdate();
            }
        }

        void AirshipControllerUpdate()
        { 
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null)
            {
                return;
            }
        
        	theScript.RPM = RPM.Value;
        }

    }
}